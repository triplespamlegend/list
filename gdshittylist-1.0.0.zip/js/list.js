const d = {
	"list": [
		/*=================================================================================*/
		{
			"vids": [
				{
					"user": "name here",
					"link": "yt link here",
					"percent": "remove these quotations and replace it with an integer (numbers)",
					"hz": "refresh rate here (Make sure you add Hz at the end"
				},

      ],
			"name": "Level name here.",
			"author": "Author name here",
			"more": "none",
			"id": "remove quotations and replace them with the level ID (integers)",
			"pass": "Level pass here",
			"percentToQualify": "remove quotations and replace them with integers (numbers)",
			"verificationVid": "verification vid link here (youtube and twitch only allowed)",
/*for legacy list add the word "legacy" behind the word key right away: "legacykey"*/
			"key": 0
		},
		/*=================================================================================*/




/*only modify version with every MAJOR update (you can always check update number at https://github.com/electroflameofficial/gdshittylist/releases*/

	],
	"version": [
		1,
		0,
		0
	]
};

const list = d.list;const version = d.version;