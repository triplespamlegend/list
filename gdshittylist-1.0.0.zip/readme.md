# Welcome to the Official first release of the shitty list fellow stranger!
---
There isnt much going on here at the moment but trust me when i tell you you have *lots* of work you have to do, mainly in html and js, and maybe even in css if you wanna refresh the looks a bit.
I suggest you start with the hard things first, list.js. it's mostly easy to learn and get used to but it will slowly feel like a chore, so get that out of the way first.
Once you're done with that, head over to index.html, where you will edit the site name, embed, discord link, and records link. there are some other things you might change depending on your list,
but that's up to you to figure out.
that's all for now, and see you in release 1.5.1!
---
# Shitty List Staff Team
---
## Owners:
- Cyns
- Fulva
- Sydney
---
## List Admins:
- GabeLucario
- Kobra
- V1nnyy
- Acidius
---
## List Moderators:
- Goodyman
- AcropolisBoy
---
## List Helpers:
- Tril
- dots
---
## Server Administrators:
- Lupe
- Nezzi
- Electro
- krissi
- Yeezo
- Magma
- Bluestone
---
## Repo Maintainers:
- Electro
- Cyns